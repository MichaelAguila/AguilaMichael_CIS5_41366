/* 
 * File:   main.cpp
 * Author: Michael Aguila
 * Created on January 10, 2021, 1:25 AM
 * Purpose:  Gaddis 9th Ed 
 *           Chapter 2
 *           Problem 9: Cyborg Data
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout << "The size of a character is " << sizeof(char) << " byte."<<endl;
    cout << "The size of an integer is " << sizeof(int) << " bytes."<<endl;
    cout << "The size of a float is " << sizeof(float) << " bytes."<<endl;
    cout << "The size of a double is " << sizeof(double) << " bytes."<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}